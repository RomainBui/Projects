input = read.table(file = "/Users/romainbui/Documents/Harvard Classes/CSIE63 - Big Data Analytics/S03/assignment/MapReduce.txt", 
           sep = "\t", stringsAsFactors = F)

map = function(key, value) # key will be 1,2 etc. value will be the text in each line
{
  value = tolower(value)
  value = gsub("[[:punct:]]","",value)
  result = unlist(strsplit(strsplit(value, "\n")[[1]], " "));
  result = as.data.frame(result)
  result = cbind(result, 1)
  names(result) = c("world", "count")
  return(result)
}

combine = function(mapresult)
{
  result = aggregate(count ~ world, data = mapresult, sum)
  return(result)
}

reduce = function(combineresult)
{
  result = do.call(rbind, combineresult)
  result = aggregate(count ~ world, data = result, sum)
  return(result);
}

combineresult = list()
for(i in 1:dim(input)[1])
{
 combineresult[[i]] = combine(map(i, input[i,]))
}
finalresult = reduce(combineresult)




