package HW11;
import java.io.File;
import java.io.IOException;

import org.neo4j.graphdb.Direction;
import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Node;
import org.neo4j.graphdb.Relationship;
import org.neo4j.graphdb.RelationshipType;
import org.neo4j.graphdb.Transaction;
import org.neo4j.graphdb.factory.GraphDatabaseFactory;
import org.neo4j.io.fs.FileUtils;


/**
 * @author romainbui
 *
 */
public class EmbeddedNeo4j {
    private static final String DB_PATH = "/Users/romainbui/Documents/Harvard Classes/CSIE63 - Big Data Analytics/S11/neo4j-community-2.2.1/data/RomainBui.db";

    public String greeting;

    // START SNIPPET: vars
    GraphDatabaseService graphDb;
    Node firstNode;
    Node secondNode;
    Node thirdNode;
    Node fourthNode;
    Node fifthNode;
    Node sixthNode;
    Node seventhNode;
    Node eigthNode;
    Node ninethNode;
    Node tenthNode;
    Node eleventhNode;
    Relationship relationship;
    // END SNIPPET: vars

    // START SNIPPET: createReltype
    private static enum RelTypes implements RelationshipType
    {
    	SEQUEL,
    }
    // END SNIPPET: createReltype

    public static void main( final String[] args ) throws IOException
    {
        EmbeddedNeo4j db = new EmbeddedNeo4j();
        db.createBookDb();
        db.shutDown();
    }

    void createBookDb() throws IOException
    {
        FileUtils.deleteRecursively( new File( DB_PATH ) );

        // START SNIPPET: startDb
        graphDb = new GraphDatabaseFactory().newEmbeddedDatabase( DB_PATH );
        registerShutdownHook( graphDb );
        // END SNIPPET: startDb

        // START SNIPPET: transaction
        try ( Transaction tx = graphDb.beginTx() )
        {
            // Database operations go here
            // END SNIPPET: transaction
            // START SNIPPET: addData
        	
        	// THE LORD OF THE RINGS
            firstNode = graphDb.createNode();
            firstNode.setProperty( "title", "The Fellowship of the Ring" );
            firstNode.setProperty("author", "J.R.R. Tolkien");
            firstNode.setProperty("date", "1954");
            
            secondNode = graphDb.createNode();
            secondNode.setProperty( "title", "The Two Towers" );
            secondNode.setProperty("author", "J.R.R. Tolkien");
            secondNode.setProperty("date", "1954");
            
            thirdNode = graphDb.createNode();
            thirdNode.setProperty( "title", "The Return of the King" );
            thirdNode.setProperty("author", "J.R.R. Tolkien");
            thirdNode.setProperty("date", "1954");
            
            secondNode.createRelationshipTo(firstNode, RelTypes.SEQUEL);
            thirdNode.createRelationshipTo(secondNode, RelTypes.SEQUEL);
            
            // HARRY POTTER
            fourthNode = graphDb.createNode();
            fourthNode.setProperty( "title", "The Philosopher's Stone" );
            fourthNode.setProperty("author", "J.K. Rowling");
            fourthNode.setProperty("date", "1997");
            
            fifthNode = graphDb.createNode();
            fifthNode.setProperty( "title", "The Chamber of Secret" );
            fifthNode.setProperty("author", "J.K. Rowling");
            fifthNode.setProperty("date", "1998");
            
            sixthNode = graphDb.createNode();
            sixthNode.setProperty( "title", "The Prisonner of Azkaban" );
            sixthNode.setProperty("author", "J.K. Rowling");
            sixthNode.setProperty("date", "1999");
            
            seventhNode = graphDb.createNode();
            seventhNode.setProperty( "title", "The Goblet of Fire" );
            seventhNode.setProperty("author", "J.K. Rowling");
            seventhNode.setProperty("date", "2000");
            
            eigthNode = graphDb.createNode();
            eigthNode.setProperty( "title", "The Order of Phoenix" );
            eigthNode.setProperty("author", "J.K. Rowling");
            eigthNode.setProperty("date", "2003");
            
            ninethNode = graphDb.createNode();
            ninethNode.setProperty( "title", "The Half Blood Prince" );
            ninethNode.setProperty("author", "J.K. Rowling");
            ninethNode.setProperty("date", "2005");
            
            tenthNode = graphDb.createNode();
            tenthNode.setProperty( "title", "The Deathly Hallows" );
            tenthNode.setProperty("author", "J.K. Rowling");
            tenthNode.setProperty("date", "2007");
            
            fifthNode.createRelationshipTo(fourthNode, RelTypes.SEQUEL);
            sixthNode.createRelationshipTo(fifthNode, RelTypes.SEQUEL);
            seventhNode.createRelationshipTo(sixthNode, RelTypes.SEQUEL);
            eigthNode.createRelationshipTo(seventhNode, RelTypes.SEQUEL);
            ninethNode.createRelationshipTo(eigthNode, RelTypes.SEQUEL);
            tenthNode.createRelationshipTo(ninethNode, RelTypes.SEQUEL);
            
            // A solo book
            eleventhNode = graphDb.createNode();
            eleventhNode.setProperty("title", "Fairy Tale (T1)");
            eleventhNode.setProperty("author", "Hiro Mashima");
            eleventhNode.setProperty("date", "2008");
            		
            
            //relationship = firstNode.createRelationshipTo( secondNode, RelTypes.KNOWS );
            //relationship.setProperty( "message", "brave Neo4j " );
            // END SNIPPET: addData

            // START SNIPPET: transaction
            tx.success();
        }
        // END SNIPPET: transaction
    	
    }

    void shutDown()
    {
        System.out.println();
        System.out.println( "Shutting down database ..." );
        // START SNIPPET: shutdownServer
        graphDb.shutdown();
        // END SNIPPET: shutdownServer
    }

    // START SNIPPET: shutdownHook
    private static void registerShutdownHook( final GraphDatabaseService graphDb )
    {
        // Registers a shutdown hook for the Neo4j instance so that it
        // shuts down nicely when the VM exits (even if you "Ctrl-C" the
        // running application).
        Runtime.getRuntime().addShutdownHook( new Thread()
        {
            @Override
            public void run()
            {
                graphDb.shutdown();
            }
        } );
    }
    // END SNIPPET: shutdownHook

}
