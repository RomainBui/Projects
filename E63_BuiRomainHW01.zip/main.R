setwd("/Users/romainbui/Documents/Harvard Classes/CSIE63 - Big Data Analytics/Assignment1")

### Problem 1 ----
# Compute the matrix and its inverse
set.seed(10)
B = matrix(data = runif(16), nrow = 4, ncol = 4)
B = B + diag(4)
Binv = solve(B)

# Verify if all the single elements are at the unit matrix +/- the default tolerance
tol = .Machine$double.eps
B%*%Binv <= diag(4) + tol & B%*%Binv >= diag(4) - tol # for large matrices one could do sum() == length(B)
all.equal(B%*%Binv, diag(4))

# Find the eigenvalues
eigB = eigen(B)
eigB$values  # eigen values of B

eigBinv = eigen(Binv)
eigBinv$values  # eigen values of Binv

eigtB = eigen(t(B))
eigtB$values   # eigen values of t(B)

#Demonstrate that matrix B multiplied by one of its eigen vectors from right results
#in a vector which is equal to the product of the corresponding eigen value and that same vector.
all.equal(as.vector(Re(B %*% eigB$vectors[,1])), Re(eigB$values[1] * eigB$vectors[,1]))
all.equal(as.vector(Im(B %*% eigB$vectors[,1])), Im(eigB$values[1] * eigB$vectors[,1]))

abs(Re(B %*% eigB$vectors[,1]) - Re(eigB$values[1] * eigB$vectors[,1]))
abs(Im(B %*% eigB$vectors[,1]) - Im(eigB$values[1] * eigB$vectors[,1]))

### Problem 2 ----
x1 = sample(1:10, size = 20, replace = T)
x2 = 2.3*x1 -1.2
x2 = x2 + rnorm(20,0,1)
plot(x1,x2)

### Problem 3 ----
covM = cov(cbind(x1,x2))
eigV = eigen(covM)$vectors

# Vectors are orthogonal
eigV[,1] %*% eigV[,2] #=0

# Or
eigV[2,1] / eigV[1,1] # gives the coefficient director of the line


### Problem 4 ----
smoker.data = read.delim(file = "smokers.txt", header = T, sep = "\t")

#a)
class(smoker.data)
mode(smoker.data)
str(smoker.data)

#b)
dim(smoker.data)

#c)
labels(smoker.data)[[2]]

#d)
smoker.data[,"Country"]
smoker.data[,"PercentSmokes"]
smoker.data[,"GDPPerCapita"]
smoker.data[,"GDPRank"]
smoker.data[,"X"]
# or using $

#e)
smoker.data[,"GDPPerCapita"] = as.numeric(gsub(",","",smoker.data[,"GDPPerCapita"]))
str(smoker.data)

#f)
smoker.data[,2]
smoker.data[,3]

#g)
plot(smoker.data[,2], 
     smoker.data[,3], 
     xlab = "PercentSmokes", 
     ylab = "GDPPerCapita", 
     main = "Scatter plot of PercentSmokes and GDPPerCapita", 
     type = "p")

#h)
bps = c(0,2000,3000,5000,10000,50000)
hist(smoker.data[,3], 
     breaks = bps, 
     xlab = "GDP/Capita", 
     labels = c("0-2k", "2k-3k","3k-5k","5k-10k","10k-50k"),
     main = "GDP/Capita Distribution", 
     ylab = "Frequency", 
     freq = T, 
     col.main = "purple")

#i)
pie(table(cut(smoker.data[,3], breaks = bps, include.lowest = T)), 
    labels = c("0-2k", "2k-3k","3k-5k","5k-10k","10k-50k"),
    main = "Pie Chart of the GDP/Capita",
    col.main = "purple")

