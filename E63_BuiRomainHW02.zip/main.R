
# Problem 1 -----
bin.dist = matrix(nrow = 60, ncol = 3);
colnames(bin.dist) = c("p0.3", "p0.5", "p0.8")
for(i in 1:60)
{
  p0.3 = dbinom(x = i, size = 60, prob = 0.3)
  p0.5 = dbinom(x = i, size = 60, prob = 0.5)
  p0.8 = dbinom(x = i, size = 60, prob = 0.8)
  bin.dist[i,] = c(p0.3, p0.5, p0.8)
}

  # Regular Way
plot(x = seq(1,60), bin.dist[,2])
  
  # Better way
matplot(x = seq(1,60), 
        y = bin.dist, type = c("b"), 
        pch = 1, 
        col=1:3, 
        main = "Binomial distribution for different P",
        xlab = "Value",
        ylab = "Density")
legend("topleft", legend = colnames(bin.dist), pch=1, col=1:3)

  # Get the quartile
myfun = function(x)
{
  res = c(quantile(x)[2:3], mean(x), sd(x), quantile(x)[4])
  names(res) = c("Q1", "Median", "Mean", "SDev", "Q3")
  return(res)
}
  # Use apply to obtain a proper table
apply(X = bin.dist, MARGIN = 2, FUN = myfun)

  # Create a box plot
boxplot(x = bin.dist, horizontal = T)

# Problem 2 -----
library(MASS)

  # Recreate the plot
plot(faithful$eruptions, faithful$waiting, xlab = "Duration", ylab = "Waiting")

  # Print Model
model = lm(waiting ~ eruptions, data = faithful)
model

  # Add the line
abline(model, col="red", lwd = 2)

  
# Problem 3 -----

  # Add a new column
faithful$type[faithful$eruptions<3.1] = "short"
faithful$type[faithful$eruptions>3.1] = "long"

  # Boxplot
boxplot(waiting~type, data = faithful, main = "Waiting Boxplot By Type", ylab = "Waiting Time (min)", xlab = "Type of Eruptions")
boxplot(eruptions~type, data = faithful, main = "Duration Boxplot By Type", ylab = "Duration (min)", xlab = "Type of Eruptions")


# Problem 4 ----

  # Uniform & Histogram
data.U = runif(1000000, min = -1, max = 2)
hist(data.U, breaks = 20, freq = F, main = "Histogram of a Uniform between -1 and 2") # Horizontal line should be at 0.33 so that (2-(-1))*x = 1


# Problem 5 ----

  # Collect the data 
data.5 = matrix(nrow = 100, ncol = 40)

myfun.5 = function(x)
{
  x = runif(100,min=-1,max=2)  
}

data.5 = apply(data.5, MARGIN = 2, myfun.5)

  # Do the plot

x = seq(-1, 2, 0.1)
y1 = as.vector(table(cut(data.5[,1], x)))/length(data.5[,1])
y2 = as.vector(table(cut(data.5[,2], x)))/length(data.5[,2])

plot(x[-1], y1, col = "red", ylab = "Relative Frequency", xlab = "Value (Upper Band)", main = "Distribution of Column 1 (red) and 2 (green)")
lines(x[-1], y2, col = "dark green", ylab = "", xlab="")


# Problem 6
  
  # Plot Hist
data.5 = cbind(data.5, as.vector(rowSums(data.5)))
hist.6 = hist(data.5[,41], breaks = 20, freq = F, main = "Histogram of the sum of the 40 uniforms", xlab = "value")

  # Check with Gaussian Distribution
mean = ((2-1)/2)*40
sd = sqrt(((2--1)**2)/12)*sqrt(40)
lines(x = hist.6$breaks, y = dnorm(hist.6$breaks, mean, sd), col = "red")






