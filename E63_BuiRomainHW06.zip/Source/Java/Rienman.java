package MR;


import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
//import org.apache.hadoop.io.IntWritable;

import java.lang.InterruptedException;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.KeyValueTextInputFormat;
import org.apache.hadoop.mapreduce.Mapper; 
//import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapreduce.Reducer; 
//import org.apache.hadoop.mapred.Reducer;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

public class Rienman extends Configured implements Tool {


private final static IntWritable uno = new IntWritable(1); 
public static double f_x_d_x;
public static String f_x_d_x_value;

    public static class RienMap extends Mapper<Text, Text, IntWritable, Text> {
    	
        public void map(Text key, Text value,
                        Context context) throws IOException, InterruptedException {
           
    	    for(int x = 1; x <= 2; x = x+1/10) 
    	    {
    	    	f_x_d_x = 1/(double)x * (10-1)/10000;
    	    	f_x_d_x_value = String.valueOf(f_x_d_x);
    	    	context.write(uno, new Text(f_x_d_x_value));
    	    }
        }
    }   
    public static class RienReduce extends Reducer<IntWritable, Text, Text, Text> {
        
        public void reduce(Text key, Iterable<Text> values,
                           Context context) throws IOException, InterruptedException {
            
        	double count=0;
            for(Text x : values)
            {
            	count += Double.parseDouble(x.toString());
            }
            context.write(key, new Text(String.valueOf(count))); // modif
        }
    }   
    public int run(String[] args) throws Exception {
        Configuration conf = getConf();      
        //conf.set("mapreduce.input.keyvaluelinerecordreader.key.value.separator", ",");
        @SuppressWarnings("deprecation")
		Job job = new Job(conf, "InverterCounter"); 
        job.setJarByClass(Rienman.class);
        Path out = new Path(args[1]);
        Path in = new Path(args[0]);
        
        FileInputFormat.setInputPaths(job, in);
        FileOutputFormat.setOutputPath(job, out);
        
        job.setMapperClass(RienMap.class);
        job.setReducerClass(RienReduce.class);   
        
        job.setInputFormatClass(KeyValueTextInputFormat.class);
        job.setOutputFormatClass(TextOutputFormat.class);
        
        job.setOutputKeyClass(IntWritable.class);
        job.setOutputValueClass(Text.class);
        //job.set("key.value.separator.in.input.line", ",");       
        //JobClient.runJob(job);      
        System.exit(job.waitForCompletion(true)?0:1);
        return 0;
    }  
    public static void main(String[] args) throws Exception { 
        int res = ToolRunner.run(new Configuration(), new Rienman(), args);       
        System.exit(res);
    }
}
