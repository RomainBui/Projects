package MR;

import java.io.IOException;
import java.util.Iterator;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.mapred.FileInputFormat;
import org.apache.hadoop.mapred.FileOutputFormat;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.KeyValueTextInputFormat;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reducer;
import org.apache.hadoop.mapred.Reporter;
import org.apache.hadoop.mapred.TextOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

public class InverterCounter extends Configured implements Tool {
	
	public static class MapInverter extends MapReduceBase
       implements Mapper<Text, Text, Text, Text> {
       
       public void map(Text key, Text value,
                       OutputCollector<Text, Text> output,
                       Reporter reporter) throws IOException {
          
       	String valueTemp = value.toString();
       	String[] parts = valueTemp.split(",");
       	value = new Text(parts[3] + "_" +parts[4]);
           output.collect(value, key);
       }
   }   
	public static class ReduceInverter extends MapReduceBase
       implements Reducer<Text, Text, Text, Text> {
       
       public void reduce(Text key, Iterator<Text> values,
                          OutputCollector<Text, Text> output, //modif
                          Reporter reporter) throws IOException {
                          
           //int count = 0;
           String csv = "";
           while (values.hasNext()) {
               if(csv.length()>0) csv += ",";
               csv += values.next().toString();
               // csv.concat(values.next().toString());
               //count++;s
           }
           output.collect(key, new Text(csv)); // modif
       }
   }   

    public static class MapCounter extends MapReduceBase
    implements Mapper<Text, Text, Text, IntWritable> {
    
    public void map(Text key, Text value,
                    OutputCollector<Text, IntWritable> output,
                    Reporter reporter) throws IOException {
        
    	String valueTemp = value.toString();
    	String[] parts = valueTemp.split(",");
        output.collect(key, new IntWritable(parts.length));
        }
    } 
    
    private JobConf createJobInverter (Configuration conf, Path in, Path out)
    {     
        JobConf job = new JobConf(conf, InverterCounter.class);    
        FileInputFormat.setInputPaths(job, in);
        FileOutputFormat.setOutputPath(job, out);
        
        job.setJobName("InverterCounter");
        job.setMapperClass(MapInverter.class);
        job.setReducerClass(ReduceInverter.class);   
        job.setInputFormat(KeyValueTextInputFormat.class);
        job.setOutputFormat(TextOutputFormat.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);
        job.set("key.value.separator.in.input.line", ",");       
        
        return job;
    }
    
    private JobConf createJobCounter (Configuration conf, Path in, Path out)
    {      
        JobConf job = new JobConf(conf, InverterCounter.class);    
        FileInputFormat.setInputPaths(job, in);
        FileOutputFormat.setOutputPath(job, out);
        
        job.setJobName("InverterCounter");
        job.setMapperClass(MapCounter.class);
        //job.setReducerClass(Reduce.class);   
        job.setInputFormat(KeyValueTextInputFormat.class);
        job.setOutputFormat(TextOutputFormat.class);
        
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(IntWritable.class); // Modif
        //job.set("key.value.separator.in.input.line", ",");  // Modif     
        
        return job;
    }
    
    private void cleanup(Path temp, Configuration conf) throws IOException
    {
    	FileSystem fs = temp.getFileSystem(conf);
    	fs.delete(temp, true);
    }
    
    public int run(String[] args) throws Exception { 
    	Configuration conf = getConf();
        Path in = new Path(args[0]);
        Path out = new Path(args[1]);
        Path temp = new Path("Chain-temp");
        JobConf job1 = createJobInverter(conf,in,temp);
        JobClient.runJob(job1);
        JobConf job2 = createJobCounter(conf, temp, out);
        JobClient.runJob(job2);
        cleanup(temp, conf);
        
        return 0;
        
    }
    
    public static void main(String[] args) throws Exception { 
        int res = ToolRunner.run(new Configuration(), new InverterCounter(), args);       
        System.exit(res);
    }
    
    
}
