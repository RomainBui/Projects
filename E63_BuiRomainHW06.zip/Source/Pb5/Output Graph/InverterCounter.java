package MR;

import java.io.IOException;


import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.IntWritable;

import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

import java.lang.InterruptedException;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.KeyValueTextInputFormat;
import org.apache.hadoop.mapreduce.Mapper; 
//import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapreduce.Reducer; 
//import org.apache.hadoop.mapred.Reducer;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

public class InverterCounter extends Configured implements Tool {
	
	public static class MapInverter extends Mapper<Text, Text, Text, Text> {
       
       public void map(Text key, Text value,
                       Context context) throws IOException, InterruptedException {
          
       	String valueTemp = value.toString();
       	String[] parts = valueTemp.split(",");
       	value = new Text(parts[3] + "_" +parts[4]);
        context.write(value, key);
       }
   }   
	public static class ReduceInverter extends Reducer<Text, Text, Text, Text> {
       
       public void reduce(Text key, Iterable<Text> values,
                          Context context) throws IOException, InterruptedException {
                          
           //int count = 0;
           String csv = "";
           
           
           for(Text parts : values)
           {
               if(csv.length()>0) csv += ",";
               csv += parts.toString();
               // csv.concat(values.next().toString());
               //count++;s
           }
           context.write(key, new Text(csv)); // modif
       }
   }   

    public static class MapCounter extends Mapper<Text, Text, Text, IntWritable> {
    
    public void map(Text key, Text value,
                    Context context) throws IOException, InterruptedException {
        
    	String valueTemp = value.toString();
    	String[] parts = valueTemp.split(",");
        context.write(key, new IntWritable(parts.length));
        }
    } 
    
    private Job createJobInverter (Configuration conf, Path in, Path out) throws IOException
    {     
    	
        @SuppressWarnings("deprecation")
		Job job = new Job(conf, "Inverter");
        job.setJarByClass(InverterCounter.class);
        
        FileInputFormat.setInputPaths(job, in);
        FileOutputFormat.setOutputPath(job, out);
        
        //job.setJobName("InverterCounter");
        job.setMapperClass(MapInverter.class);
        job.setReducerClass(ReduceInverter.class);   
        job.setInputFormatClass(KeyValueTextInputFormat.class);
        job.setOutputFormatClass(TextOutputFormat.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);
        
        //job.set("key.value.separator.in.input.line", ",");       
        
        return job;
    }
    
    private Job createJobCounter (Configuration conf, Path in, Path out) throws IOException
    {      
        @SuppressWarnings("deprecation")
		Job job = new Job(conf, "Counter");  
        job.setJarByClass(InverterCounter.class);
        
        FileInputFormat.setInputPaths(job, in);
        FileOutputFormat.setOutputPath(job, out);
        
        //job.setJobName("InverterCounter");
        job.setMapperClass(MapCounter.class);
        //job.setReducerClass(Reduce.class);   
        job.setInputFormatClass(KeyValueTextInputFormat.class);
        job.setOutputFormatClass(TextOutputFormat.class);
        
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(IntWritable.class); // Modif
        //job.set("key.value.separator.in.input.line", ",");  // Modif     
        
        return job;
    }
    
    private void cleanup(Path temp, Configuration conf) throws IOException
    {
    	FileSystem fs = temp.getFileSystem(conf);
    	fs.delete(temp, true);
    }
    
    public int run(String[] args) throws Exception { 
    	Configuration conf = getConf();
    	conf.set("mapreduce.input.keyvaluelinerecordreader.key.value.separator", ",");
        Path in = new Path(args[0]);
        Path out = new Path(args[1]);
        Path temp = new Path("Chain-temp");
        Job job1 = createJobInverter(conf,in,temp);
        job1.waitForCompletion(true);
        
        //JobClient.runJob(job1);s
        conf = getConf();
        Job job2 = createJobCounter(conf, temp, out);
        System.exit(job2.waitForCompletion(true)?0:1);
        //JobClient.runJob(job2);
        //cleanup(temp, conf);
        
        return 0;
        
    }
    
    public static void main(String[] args) throws Exception { 
        int res = ToolRunner.run(new Configuration(), new InverterCounter(), args);       
        System.exit(res);
    }
    
    
}
