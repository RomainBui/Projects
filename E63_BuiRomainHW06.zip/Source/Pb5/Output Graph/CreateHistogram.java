package MR;

import java.io.IOException;
import java.util.Iterator;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.FileInputFormat;
import org.apache.hadoop.mapred.FileOutputFormat;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.KeyValueTextInputFormat;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reducer;
import org.apache.hadoop.mapred.Reporter;
import org.apache.hadoop.mapred.TextOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

public class CreateHistogram extends Configured implements Tool 
{
	private final static IntWritable uno = new IntWritable(1);
    
	public static class Map1 extends MapReduceBase
    implements Mapper<Text, Text, Text, IntWritable> {
    
	    public void map(Text key, Text value,
	                    OutputCollector<Text, IntWritable> output,
	                    Reporter reporter) throws IOException {
	                    
	        output.collect(value, uno);
	    }
	}  
	
	public static class Reduce1 extends MapReduceBase
	    implements Reducer<Text, IntWritable, Text, IntWritable> {
	    
	    public void reduce(Text key, Iterator<IntWritable> values,
	                       OutputCollector<Text, IntWritable> output,
	                       Reporter reporter) throws IOException {
	                       
	        int count = 0;
	        while (values.hasNext()) {
	            values.next();
	            count++;
	        }
	        output.collect(key, new IntWritable(count));
	    }
	}  
	
	public static class Map2 extends MapReduceBase
	implements Mapper<Text, Text, IntWritable, IntWritable> {
	
	//private final static IntWritable uno = new IntWritable(1);
	public static IntWritable floorIntWritable = new IntWritable();
	public static IntWritable NbOfPatent = new IntWritable();
	//public static double citationCountDouble;
	public static int floor = 0;
	
	public void map(Text key, Text value,
	                OutputCollector<IntWritable, IntWritable> output,
	                Reporter reporter) throws IOException {
	                
		
		floor =  (int)Math.floor((((Double.parseDouble(key.toString())-1.0)/20.0))+1.0);
		floorIntWritable.set(floor);
		
		NbOfPatent.set((int)Double.parseDouble(value.toString()));
		
	    output.collect(floorIntWritable, NbOfPatent);
	}
	}
	
	public static String histBar;
	public static String lowerBand;
	public static String upperBand;
	
	public static class Reduce2 extends MapReduceBase
	implements Reducer<IntWritable,IntWritable,Text,Text>
	{
	public void reduce(IntWritable key, Iterator<IntWritable> values,
						OutputCollector<Text, Text>output,           
	                   Reporter reporter) throws IOException {
	                  
		int count = 0;
	    int countasterix = 0;
	    histBar = "";
	    lowerBand = "";
	    upperBand = "";
	    
	    while (values.hasNext()) {
	        count += values.next().get();
	    }
	    
	    countasterix = (int)Math.round((4.0*Math.log10((double)count))+1.0);
	    lowerBand = Integer.toString(((Integer.parseInt(key.toString())-1) * 20)+1);
	    upperBand = Integer.toString(((Integer.parseInt(key.toString())  ) * 20)  );
	    lowerBand = lowerBand.concat("-");
	    lowerBand = lowerBand.concat(upperBand);
	    
	    for(int x = 0; x < countasterix; x = x+1) 
	    {
	    	histBar = histBar + "*";
	    }
	    Text asterixtext = new Text(histBar);
	    Text keytext  = new Text(lowerBand);

	    output.collect(keytext,asterixtext);
	}
	}

	
	private JobConf createJob1(Configuration conf, Path in, Path out) 
	{
		JobConf job = new JobConf(conf, CreateHistogram.class);
		job.setJobName("job1");
		FileInputFormat.setInputPaths(job, in);
		FileOutputFormat.setOutputPath(job, out);
		job.setMapperClass(Map1.class); 
		job.setReducerClass(Reduce1.class);
		job.setInputFormat(KeyValueTextInputFormat.class);
		job.setOutputFormat(TextOutputFormat.class);
		//job.set("key.value.separator.in.input.line", ",");
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(IntWritable.class); 
		return job;
	}
		
	private JobConf createJob2(Configuration conf, Path in, Path out) 
	{
		JobConf job = new JobConf(conf, CreateHistogram.class);
		job.setJobName("job2");
		FileInputFormat.setInputPaths(job, in);
		FileOutputFormat.setOutputPath(job, out);
		job.setMapperClass(Map2.class); 
		job.setReducerClass(Reduce2.class);
		
		job.setInputFormat(KeyValueTextInputFormat.class);
		job.setOutputFormat(TextOutputFormat.class);
		job.setMapOutputKeyClass(IntWritable.class);
		job.setMapOutputValueClass(IntWritable.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(Text.class); 
		return job;
	}
	
	private void cleanup(Path temp, Configuration conf)
		throws IOException 
	{
		FileSystem fs = temp.getFileSystem(conf);
		fs.delete(temp, true);
	}
	
	public int run(String[] args) throws Exception 
	{
		Configuration conf = getConf();
		Path in = new Path(args[0]);
		Path out = new Path(args[1]);
		Path temp = new Path("chain-temp");
		JobConf job1 = createJob1(conf, in, temp);
		JobClient.runJob(job1);
		JobConf job2 = createJob2(conf, temp, out);
		JobClient.runJob(job2);
		//cleanup(temp, conf); 
		return 0;
	}
	
	public static void main(String[] args) throws Exception 
	{
		int res = ToolRunner.run(new Configuration(), new CreateHistogram(), args);
		System.exit(res);
	}
	
}
