package romain.MR.update;

import java.util.ArrayList;
import java.util.List;


import java.io.IOException;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.lang.String;


import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Mapper.Context;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;


public class WordCount {

	private final static IntWritable one = new IntWritable(1);
	private Text word = new Text();
    public void map(Object key, Text value) throws IOException, InterruptedException {
    	StringTokenizer itr = new StringTokenizer(value.toString().replaceAll("\\p{P}", ""));
    	while (itr.hasMoreTokens()) {
    		word.set(itr.nextToken());
    		System.out.println(word + " "+ one + "\n");
    		// Fill the context here
    	}
    }
  
 private IntWritable result = new IntWritable();

 public void reduce(Text key, Iterable<IntWritable> values) throws IOException, InterruptedException {
   int sum = 0;
   for (IntWritable val : values) {
     sum += val.get();
   }
   
   Pattern pattern = Pattern.compile("[0-9]");
   Matcher matcher = pattern.matcher(key.toString());
   if(matcher.find())
   {
	   sum = 0;  // If the key is a series of digits (like the verset would) return a 0.
   }
		   
   result.set(sum);

   if(sum > 1000)
   {
	   System.out.println(key + " " + result);
	   // Fill the context here
	}
   
}

  public static void main(String[] args) throws Exception {
	  WordCount romain = new WordCount();
	  //romain.map(1, new Text(args[0]));
	  
	  List <IntWritable> values = new ArrayList<IntWritable>();
	  values.add(new IntWritable(10000));
	  Iterable<IntWritable> iterable = values;
	  
	  romain.reduce(new Text("01010111"), iterable);
	  
	 
  }
}
