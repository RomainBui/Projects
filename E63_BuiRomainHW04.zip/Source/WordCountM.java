package romain.MR.update;

import java.io.IOException;
import java.util.StringTokenizer;
import java.lang.String;


import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;


public class WordCount {

	private final static IntWritable one = new IntWritable(1);
	private Text word = new Text();
    public void map(Object key, Text value) throws IOException, InterruptedException {
    	StringTokenizer itr = new StringTokenizer(value.toString().replaceAll("\\p{P}", ""));
    	while (itr.hasMoreTokens()) {
    		word.set(itr.nextToken());
    		System.out.println(word + " "+ one + "\n");
    	}
    }

  public static void main(String[] args) throws Exception {
	  WordCount romain = new WordCount();
	  romain.map(1, new Text(args[0]));
  }
}
