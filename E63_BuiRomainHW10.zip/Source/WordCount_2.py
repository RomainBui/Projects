from pyspark import SparkConf, SparkContext
import string, re
conf = SparkConf().setMaster("local").setAppName("YourApp")
sc = SparkContext(conf = conf)
rdd = sc.textFile("file:///home/cloudera/all-bible.txt")
resultTemp = rdd.map(lambda x : x.encode('utf-8').translate(None, ",|?|!|:|;").lower())
#resultTemp2 = resultTemp.flatMap( lambda x : re.findall('([a-z]+)\s+(?=([a-z]+)|\.)',x))
resultTemp2 = resultTemp.flatMap( lambda x : [' '.join(y) for y in re.findall('([a-z]+)\s+(?=([a-z]+)|\.)',x)])
#resultTemp3 = [' '.join(x) for x in resultTemp2]
result = resultTemp2.map(lambda x: (x, 1)).reduceByKey(lambda x, y: x + y)
result = result.map(lambda(x,y) : (y,x))
result = result.sortByKey()
result.saveAsTextFile("file:///home/cloudera/res")