from pyspark import SparkConf, SparkContext
import string
conf = SparkConf().setMaster("local").setAppName("YourApp")
sc = SparkContext(conf = conf)
rdd = sc.textFile("hdfs://quickstart.cloudera:8020/user/cloudera/hw10/all-bible.txt")
words = rdd.flatMap(lambda x: x.split(" "))
#remove_punctuation_map = dict((ord(char), None) for char in string.punctuation)
#resultTemp = words.map(lambda x : x.translate(remove_punctuation_map))
resultTemp = words.map(lambda x : x.encode('utf-8').translate(None, string.punctuation).lower()) #Delete the punctuation and Case
resultTemp = resultTemp.filter(lambda x : not unicode(x,'utf-8').isnumeric()) # Do not take numerics
result = resultTemp.map(lambda x: (x, 1)).reduceByKey(lambda x, y: x + y)
result.saveAsTextFile("hdfs://quickstart.cloudera:8020/user/cloudera/hw10/res2")